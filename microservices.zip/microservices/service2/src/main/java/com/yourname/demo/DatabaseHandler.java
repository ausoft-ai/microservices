package com.yourname.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DatabaseHandler {

    private static final Logger logger = LogManager.getLogger(DatabaseHandler.class);    
 
    private String url;
    private String username;
    private String password;
    
    public void DatabaseHandler(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }
        
    
    public void InsertRegistration(Registration entity) {

        try {
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            try {
                  
                // Establish a connection to the database
                Connection connection = DriverManager.getConnection(url,
                        username, password);

                // SQL statement for the insert
                String insertSQL = "INSERT INTO r_registration (r_name,r_surname,r_age) "
                        + "VALUES (?, ?, ?)";

                // Create a PreparedStatement with the SQL statement
                PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);

                // Set values for the parameters in the SQL statement
                preparedStatement.setString(1, entity.getName());
                preparedStatement.setString(2, entity.getSurname());
                preparedStatement.setInt(3, entity.getAge());

                // Execute the insert statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    logger.info("Insert successful. " + rowsAffected + " row(s) affected.");
                } else {
                    logger.error("Insert failed.");
                }

                // Close the PreparedStatement and the database connection
                preparedStatement.close();
                connection.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            logger.error(e.getMessage());
        }
    }
}
