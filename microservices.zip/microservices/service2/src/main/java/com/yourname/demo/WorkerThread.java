package com.yourname.demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties
public class WorkerThread {

    private boolean active = true;
    private String url;
    private String username;
    private String password;
    private String amq;

    private static final Logger logger = LogManager.getLogger(WorkerThread.class);

    private void sleep() {
        try {
            wait(1000);
        } catch (InterruptedException ex) {
            logger.error(ex.getMessage());
        }
    }

    public void run() {
        PropertyReader env = new PropertyReader();
        
        this.url = env.read("datasource.url");
        this.username = env.read("datasource.username");
        this.password = env.read("datasource.password");
        this.amq = env.read("amq.url");
        
        while (active) {
            logger.info("Read Message Queue");
            MessageHandler messageHandler = new MessageHandler();
            messageHandler.readQueue(amq, "Registrations");
            sleep();
        }
    }
}
