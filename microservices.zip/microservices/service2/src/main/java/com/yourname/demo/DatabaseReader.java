package com.yourname.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DatabaseReader {

    private static final Logger logger = LogManager.getLogger(DatabaseReader.class);

    private String url;
    private String username;
    private String password;
    
    public void DatabaseReader(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }
    
    public List<Registration> ReadRegistrations() {

        List<Registration> registrations = new ArrayList<>();

        try {
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            try {

                // Establish a connection to the database
                Connection connection = DriverManager.getConnection(url,
                        username, password);

                Statement statement = connection.createStatement();

                String sqlQuery = "SELECT * FROM r_registration";

                // Execute the query and get the result set
                ResultSet resultSet = statement.executeQuery(sqlQuery);

                // Process the result set
                while (resultSet.next()) {
                    Registration r = new Registration();
                    
                    r.setId(resultSet.getLong("r_id"));
                    r.setName(resultSet.getString("r_name"));
                    r.setSurname(resultSet.getString("r_surname"));
                    r.setAge(resultSet.getInt("r_age"));
                    
                    registrations.add(r);

                }

                // Close the result set, statement, and connection
                resultSet.close();
                statement.close();
                connection.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            logger.error(e.getMessage());
        }
        return registrations;
    }
}
