/*
Author: Theo Venter
Date: 03 November 2023
 */
package com.yourname.demo;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.RestController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
public class Controller {
    
    @Autowired
    private Environment env;    

    private static final Logger logger = LogManager.getLogger(Controller.class);
    
    @GetMapping("/api/v1/registrations")
    List<Registration> getRegistrations() {
        

       
        List<Registration> registrations = new ArrayList<>();
        
        DatabaseReader db = new DatabaseReader();
        registrations = db.ReadRegistrations();
        
        return registrations;
    }

}
