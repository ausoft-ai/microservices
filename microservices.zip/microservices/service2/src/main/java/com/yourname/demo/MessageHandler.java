package com.yourname.demo;

import javax.jms.*;
import org.json.*;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MessageHandler {

    private static final Logger logger = LogManager.getLogger(MessageHandler.class);

    public static void readQueue(String brokerURL, String queueName) {
 
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);

        try {
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(queueName);

            MessageConsumer consumer = session.createConsumer(destination);

            while (true) {
                try {
                    Message message = consumer.receive(5000); // Receive a message

                    if (message instanceof TextMessage) {
                        TextMessage textMessage = (TextMessage) message;
                        String text = textMessage.getText();
                        logger.info("Received: " + text);

                        Registration entity = new Registration();
                        
                        // read our customer registration data from a JSON body
                        JSONObject obj = new JSONObject(text);

                        entity.setName(obj.getString("name"));
                        entity.setSurname(obj.getString("surname"));
                        entity.setAge(obj.getInt("age"));

                        DatabaseHandler db = new DatabaseHandler();
                        
                        db.InsertRegistration(entity);
                    } else {
                        logger.info("Received message of unsupported type: " + message.getClass().getName());
                    }
                } catch (Exception e) {
                }
            }
        } catch (JMSException e) {
            logger.error(e.getMessage());
        }
    }
}
