/*
Author: Theo Venter
Date: 03 November 2023
 */
package com.yourname.demo;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.json.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import io.micrometer.core.annotation.Timed;


@RestController
public class Controller {

    private static final Logger logger = LogManager.getLogger(Controller.class);

    @Timed(value = "Controller.register", description = "Time taken to execute register")
    @PostMapping("/api/v1/register")
    String register(@RequestBody String body) {

        // read our customer registration data from a JSON body
        JSONObject obj = new JSONObject(body);

        String name = obj.getString("name");
        String surname = obj.getString("surname");
        int age = obj.getInt("age");
        String dob = obj.getString("dob");
    
        // return a message to the API caller
        String response = "Customer Registration Pending";

        // all values are required for the customer registration
        if (name.length() == 0
                || surname.length() == 0
                || age == 0
                || dob.length() == 0) {
            response = "Registration failed, all values must be provided (name, surname, age, dob)";
        } else {
            MessageHandler messageHandler = new MessageHandler();
            messageHandler.addMessage(obj.toString());
            System.out.println("addMessage=" + obj.toString());
        }

        logger.info("New Customer Registration | Name: {} | Surname: {} | Age: {} | DOB: {} | Response: {}", name, surname, age, dob, response);

        return response;
    }

}
