package com.yourname.demo;

import org.apache.activemq.ActiveMQConnectionFactory;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class MessageHandler {

    private static final Logger logger = LogManager.getLogger(MessageHandler.class);

    public static void addMessage(String json) {
        try {
            // Create a ConnectionFactory
            PropertyReader properties = new PropertyReader();
            String amq = properties.read("amq.url");
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(amq); // ActiveMQ broker URL

            // Create a Connection
            Connection connection = connectionFactory.createConnection();
            connection.start();

            // Create a Session
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            // Specify the queue name
            Destination destination = session.createQueue("Registrations"); 

            // Create a MessageProducer
            MessageProducer producer = session.createProducer(destination);

            // Create and send a text message
            TextMessage message = session.createTextMessage(json);
            producer.send(message);

            // Clean up
            session.close();
            connection.close();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }
}
