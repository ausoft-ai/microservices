package com.yourname.demo;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {

    public String read(String property) {
        String fileName = "application.properties";
        
        Properties properties = new Properties();

        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            properties.load(fileInputStream);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1); 
        }

        // Access settings by their keys
        String value = properties.getProperty(property);
        
        return value;
    }
}
